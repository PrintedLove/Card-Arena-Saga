﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCombat : MonoBehaviour
{
    public Animator animator;
    Rigidbody2D rigid;
    public Transform Enemy_AttackPoint; //몬스터의 공격 포인트 단지 그점을 참조 
    public float Enemy_attackRange = 15f; //몬스터의 공격 범위
    public LayerMask PlayerLayers; // 어떤 객체가 적이며 여기 레이어에 모든 환경의 물체감지하기 위해 변수 생성 
    //public int Enemy_attackMotion = 1;
    private bool flag = true;

    private void Start()
    {
        rigid = GetComponent<Rigidbody2D>();
    }
    void Update()
    {
        Attack();
        
    }

    void Attack()
    {
        Collider2D[] HitPlayers =  Physics2D.OverlapCircleAll(Enemy_AttackPoint.position,Enemy_attackRange,PlayerLayers); // 

        foreach(Collider2D player in HitPlayers)
        {
            if (player.name == "Player")
            {
                if (flag)
                {
                    flag = false;
                    Attack_Ani();
                    Invoke("KnockBack", 1f);
                }
                //Debug.Log("We hit " + player.name + HitPlayers.Length);
            }
        }
        
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(Enemy_AttackPoint.position, Enemy_attackRange);
    }

    void Attack_Ani()
    {
        animator.SetTrigger("Attack");
        Debug.Log("공격");
    }
    public void KnockBack() // 튕겨나가는 함수
    {

        rigid.AddForce(new UnityEngine.Vector2(3, 1) * 80, ForceMode2D.Impulse);
    }
}
